<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.2" name="prueba" tilewidth="24" tileheight="33" tilecount="135" columns="5">
 <image source="prueba.png" width="128" height="896"/>
</tileset>
